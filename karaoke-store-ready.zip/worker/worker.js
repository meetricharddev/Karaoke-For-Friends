// 卡拉OK點歌機 — YouTube API 代理（Cloudflare Worker）
// 作用：YouTube API 金鑰只放在這裡（不會出現在網頁或 App 裡），並提供快取、每日額度上限與每 IP 限流，
//       讓一般使用者不需要自己申請金鑰。
// 設定（Cloudflare 後台 → Workers → 你的 Worker → Settings）：
//   Secret   YOUTUBE_API_KEY   你的金鑰
//   KV 綁定  KV                快取與額度計數（變數名稱必須是 KV）
//   Variable ALLOWED_ORIGINS   允許呼叫的網址，逗號分隔，例如 https://karaoke.pages.dev,https://localhost
//   Variable DAILY_BUDGET      （選填）每日最多使用的額度單位，預設 9000（YouTube 免費上限是 10000）
//   Secret   ADMIN_TOKEN       你自己訂的「管理密碼」（長一點），用來產生升級碼（admin.html 會用到）
const REGION = {
  hk: { code: 'HK', kw: '粵語 新歌', lang: 'zh-HK' },
  cn: { code: '', kw: '華語 新歌 MV', lang: 'zh-CN' },
  tw: { code: 'TW', kw: '華語 新歌', lang: 'zh-TW' },
  jp: { code: 'JP', kw: '新曲 MV', lang: 'ja' },
  kr: { code: 'KR', kw: '신곡 MV', lang: 'ko' },
  us: { code: 'US', kw: 'official music video', lang: 'en' },
  eu: { code: 'GB', kw: 'official music video', lang: 'en' },
};
const CHARTS = new Set(['HK', 'TW', 'JP', 'KR', 'US', 'GB']);
const TTL = { search: 24 * 3600, chart: 3 * 3600, nw: 6 * 3600, videos: 6 * 3600 };   // 秒（遠低於 YouTube 規定的 30 天）
const YT = 'https://www.googleapis.com/youtube/v3/';
const IP_LIMIT_PER_MIN = 15;     // 每個 IP 每分鐘最多幾次「未命中快取」的上游呼叫

const dec = s => String(s || '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCharCode(+n));
const item = (id, sn, st) => ({
  id, title: dec(sn.title), channel: dec(sn.channelTitle),
  views: parseInt((st && st.viewCount) || '0', 10) || 0, published: sn.publishedAt || '',
  thumb: ((sn.thumbnails && (sn.thumbnails.medium || sn.thumbnails.default)) || {}).url || `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
});
// ---- 升級碼系統：每組碼產生後 24 小時內可輸入；輸入成功後，該裝置永久升級 ----
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // 排除容易看錯的 I O 0 1
const CODE_TTL = 86400;                              // 秒
function newCode() { const a = new Uint8Array(8); crypto.getRandomValues(a); return Array.from(a, x => ALPHA[x % 32]).join(''); }
const fmtCode = c => c.slice(0, 4) + '-' + c.slice(4);
const normCode = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function safeEq(a, b) {
  a = String(a); b = String(b); if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0;
}
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

function corsHeaders(req, env) {
  const origin = req.headers.get('Origin') || '';
  const list = String(env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean);
  const h = { 'Vary': 'Origin' };
  if (list.includes('*')) h['Access-Control-Allow-Origin'] = '*';
  else if (origin && list.includes(origin)) h['Access-Control-Allow-Origin'] = origin;
  h['Access-Control-Allow-Methods'] = 'GET, OPTIONS';
  h['Access-Control-Allow-Headers'] = 'Content-Type';
  return h;
}
const reply = (obj, status, cors) => new Response(JSON.stringify(obj), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...cors },
});

// ---- 儲存：優先用 KV；沒綁定時退而用 Cache API（只在自訂網域有效） ----
async function kget(env, key) {
  if (env.KV) return await env.KV.get(key);
  const r = await caches.default.match(new Request('https://cache.invalid/' + encodeURIComponent(key)));
  return r ? await r.text() : null;
}
async function kput(env, key, val, ttl) {
  if (env.KV) return env.KV.put(key, val, { expirationTtl: Math.max(60, ttl) });
  return caches.default.put(new Request('https://cache.invalid/' + encodeURIComponent(key)),
    new Response(val, { headers: { 'Cache-Control': 'max-age=' + ttl } }));
}
async function kdel(env, key) {
  if (env.KV) return env.KV.delete(key);
  return caches.default.delete(new Request('https://cache.invalid/' + encodeURIComponent(key)));
}
async function rate(env, ip, bucket, limit) {   // 每 IP 每分鐘次數限制
  const rk = bucket + ':' + ip + ':' + Math.floor(Date.now() / 60000);
  const n = parseInt(await kget(env, rk) || '0', 10);
  if (n >= limit) throw new HttpError(429, '嘗試次數過多，請稍後再試');
  await kput(env, rk, String(n + 1), 60);
}
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });   // YouTube 額度以太平洋時間午夜重置

async function guard(env, ip, cost) {
  // 每 IP 每分鐘限流
  const rk = 'rl:' + ip + ':' + Math.floor(Date.now() / 60000);
  const n = parseInt(await kget(env, rk) || '0', 10);
  if (n >= IP_LIMIT_PER_MIN) throw new HttpError(429, '操作太頻繁，請稍後再試');
  await kput(env, rk, String(n + 1), 60);
  // 每日額度上限
  const budget = parseInt(env.DAILY_BUDGET || '9000', 10), uk = 'u:' + today();
  const used = parseInt(await kget(env, uk) || '0', 10);
  if (used + cost > budget) throw new HttpError(429, '今日的搜尋額度已用完，請明天再試，或改用「貼上連結點歌」');
  await kput(env, uk, String(used + cost), 2 * 86400);
}

async function upstream(env, path, params) {
  if (!env.YOUTUBE_API_KEY) throw new HttpError(500, '伺服器尚未設定 YouTube API 金鑰');
  const r = await fetch(YT + path + '?' + new URLSearchParams({ ...params, key: env.YOUTUBE_API_KEY }));
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (!r.ok || j.error) {
    const reason = (j.error && j.error.errors && j.error.errors[0] && j.error.errors[0].reason) || '';
    if (/quota|rateLimit/i.test(reason)) throw new HttpError(429, '今日的搜尋額度已用完，請明天再試，或改用「貼上連結點歌」');
    throw new HttpError(502, 'YouTube 服務暫時無法使用');
  }
  return j.items || [];
}

// search.list 不含觀看數，所以再用 videos.list 補上觀看數與上傳日期（多花 1 單位）
async function enrich(env, found) {
  const ids = found.filter(i => i.id && i.id.videoId).map(i => i.id.videoId);
  if (!ids.length) return [];
  return (await upstream(env, 'videos', { part: 'snippet,statistics', id: ids.join(','), maxResults: '50' }))
    .map(i => item(i.id, i.snippet, i.statistics));
}

async function cached(env, ctx, ip, key, ttl, cost, build) {
  const hit = await kget(env, 'c:' + key);
  if (hit) return hit;
  await guard(env, ip, cost);
  const body = JSON.stringify({ items: await build() });
  ctx.waitUntil(kput(env, 'c:' + key, body, ttl));
  return body;
}

async function admin(req, env, ip, url) {
  const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS', 'Vary': 'Origin' };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  try {
    if (!env.ADMIN_TOKEN) throw new HttpError(500, '伺服器尚未設定 ADMIN_TOKEN');
    if (!env.KV) throw new HttpError(500, '伺服器尚未設定 KV');
    await rate(env, ip, 'ad', 20);
    const tok = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    if (!safeEq(tok, env.ADMIN_TOKEN)) throw new HttpError(401, '管理密碼錯誤');
    const q = url.searchParams, p = url.pathname;
    if (p === '/admin/new-code') {
      const n = Math.min(20, Math.max(1, parseInt(q.get('n') || '1', 10) || 1)), out = [];
      for (let i = 0; i < n; i++) {
        const c = newCode();
        await env.KV.put('code:' + c, JSON.stringify({ c: Date.now() }), { expirationTtl: CODE_TTL });
        out.push({ code: fmtCode(c), expires: new Date(Date.now() + CODE_TTL * 1000).toISOString() });
      }
      return reply({ codes: out }, 200, cors);
    }
    const dev = q.get('dev') || '';
    if ((p === '/admin/grant' || p === '/admin/revoke') && !/^[a-z0-9]{16,40}$/.test(dev)) throw new HttpError(400, '裝置代碼不正確');
    if (p === '/admin/grant') { await env.KV.put('dev:' + dev, JSON.stringify({ paid: true, at: Date.now(), by: 'admin' })); return reply({ ok: true }, 200, cors); }
    if (p === '/admin/revoke') { await env.KV.delete('dev:' + dev); return reply({ ok: true }, 200, cors); }
    throw new HttpError(404, 'not found');
  } catch (e) {
    if (e instanceof HttpError) return reply({ error: e.message }, e.status, cors);
    return reply({ error: '伺服器發生錯誤' }, 500, cors);
  }
}

export default {
  async fetch(req, env, ctx) {
    const ip0 = req.headers.get('CF-Connecting-IP') || 'local', u0 = new URL(req.url);
    if (u0.pathname.startsWith('/admin/')) return admin(req, env, ip0, u0);
    const cors = corsHeaders(req, env);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (req.method !== 'GET') return reply({ error: 'method not allowed' }, 405, cors);
    const url = new URL(req.url), p = url.pathname, q = url.searchParams;
    const ip = req.headers.get('CF-Connecting-IP') || 'local';
    try {
      let body;
      if (p === '/yt/search') {
        const s = (q.get('q') || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 80);
        if (!s) throw new HttpError(400, '請輸入關鍵字');
        body = await cached(env, ctx, ip, 's2:' + s.toLowerCase(), TTL.search, 101, async () =>
          enrich(env, await upstream(env, 'search', { part: 'snippet', type: 'video', videoEmbeddable: 'true', maxResults: '25', q: s })));
      } else if (p === '/yt/chart') {
        const code = (q.get('region') || '').toUpperCase();
        if (!CHARTS.has(code)) throw new HttpError(400, '不支援的地區');
        body = await cached(env, ctx, ip, 'chart:' + code, TTL.chart, 1, async () =>
          (await upstream(env, 'videos', { part: 'snippet,statistics', chart: 'mostPopular', videoCategoryId: '10', regionCode: code, maxResults: '30' }))
            .map(i => item(i.id, i.snippet, i.statistics)));
      } else if (p === '/yt/new') {
        const R = REGION[q.get('region') || ''];
        if (!R) throw new HttpError(400, '不支援的地區');
        const day = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10) + 'T00:00:00Z';   // 以「天」為單位，方便快取
        body = await cached(env, ctx, ip, 'n2:' + q.get('region') + ':' + day, TTL.nw, 101, async () => {
          const params = { part: 'snippet', type: 'video', videoCategoryId: '10', order: 'viewCount', maxResults: '25',
            q: R.kw, relevanceLanguage: R.lang, publishedAfter: day };
          if (R.code) params.regionCode = R.code;
          return enrich(env, await upstream(env, 'search', params));
        });
      } else if (p === '/yt/videos') {
        const ids = (q.get('ids') || '').split(',').filter(x => /^[\w-]{11}$/.test(x)).slice(0, 50);
        if (!ids.length) throw new HttpError(400, '缺少影片編號');
        body = await cached(env, ctx, ip, 'videos:' + ids.join(','), TTL.videos, 1, async () =>
          (await upstream(env, 'videos', { part: 'snippet,statistics', id: ids.join(','), maxResults: '50' })).map(i => item(i.id, i.snippet, i.statistics)));
      } else if (p === '/redeem') {
        // 輸入升級碼：碼必須在產生後 24 小時內、且只能用一次；成功後這台裝置永久升級
        if (!env.KV) throw new HttpError(500, '伺服器尚未設定 KV');
        await rate(env, ip, 'rd', 10);
        const dev = q.get('dev') || '';
        if (!/^[a-z0-9]{16,40}$/.test(dev)) throw new HttpError(400, '裝置代碼不正確');
        if (await kget(env, 'dev:' + dev)) return reply({ ok: true, already: true }, 200, cors);   // 已升級就不消耗升級碼
        const code = normCode(q.get('code'));
        if (code.length !== 8) throw new HttpError(400, '升級碼格式不正確');
        const raw = await kget(env, 'code:' + code);
        let rec = null; try { rec = raw ? JSON.parse(raw) : null; } catch (e) {}
        if (!rec || Date.now() - rec.c > CODE_TTL * 1000)
          return reply({ ok: false, error: '升級碼無效、已使用或已過期（每組只有產生後 24 小時內有效）' }, 200, cors);
        await kdel(env, 'code:' + code);
        await env.KV.put('dev:' + dev, JSON.stringify({ paid: true, at: Date.now() }));   // 不設期限 = 永久
        return reply({ ok: true }, 200, cors);
      } else if (p === '/entitlement') {
        if (!env.KV) throw new HttpError(500, '伺服器尚未設定 KV');
        await rate(env, ip, 'en', 30);
        const dev = q.get('dev') || '';
        if (!/^[a-z0-9]{16,40}$/.test(dev)) throw new HttpError(400, '裝置代碼不正確');
        return reply({ paid: !!(await kget(env, 'dev:' + dev)) }, 200, cors);
      } else if (p === '/' || p === '/health') {
        return reply({ ok: true }, 200, cors);
      } else {
        throw new HttpError(404, 'not found');
      }
      return new Response(body, { status: 200, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...cors } });
    } catch (e) {
      if (e instanceof HttpError) return reply({ error: e.message }, e.status, cors);
      return reply({ error: '伺服器發生錯誤' }, 500, cors);
    }
  },
};
